require('./bootstrap');

require('alpinejs');

//const Swal = require('sweetalert2');
window.Swal = require('sweetalert2');   /* Se trae el sweetalert2 de  node_modules */
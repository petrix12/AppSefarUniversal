@extends('adminlte::page')

@section('title', 'Demo')

@section('content_header')
    <h1>Demo</h1>
@stop

@section('content')
    <p>Demo.</p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')

@stop
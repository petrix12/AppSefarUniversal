<?php return array (
  'consulta.onidexes-table' => 'App\\Http\\Livewire\\Consulta\\OnidexesTable',
  'crud.permissions-table' => 'App\\Http\\Livewire\\Crud\\PermissionsTable',
  'crud.roles-table' => 'App\\Http\\Livewire\\Crud\\RolesTable',
  'crud.users-table' => 'App\\Http\\Livewire\\Crud\\UsersTable',
);
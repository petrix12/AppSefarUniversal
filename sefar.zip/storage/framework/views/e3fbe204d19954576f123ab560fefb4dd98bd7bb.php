[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xampp\htdocs\sefar\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>
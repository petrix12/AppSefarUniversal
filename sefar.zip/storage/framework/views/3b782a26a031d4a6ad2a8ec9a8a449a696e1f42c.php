

<?php $__env->startSection('title', 'Resultados de búsqueda'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('consulta.onidexes-table',   [
                    'search' => $search,
                    'nombre1' => $nombre1,
                    'nombre2' => $nombre2,
                    'apellido1' => $apellido1,
                    'apellido2' => $apellido2,
                    'cedula' => $cedula,
                    'nacion' => $nacion,
                    'cbx_nombre1' => $cbx_nombre1,
                    'cbx_nombre2' => $cbx_nombre2,
                    'cbx_apellido1' => $cbx_apellido1,
                    'cbx_apellido2' => $cbx_apellido2,
                    'cbx_nombre' => $cbx_nombre,
                    'cbx_apellido' => $cbx_apellido,
                    'cbx_cedula' => $cbx_cedula,
                    'fec_nac' => $fec_nac,
                    'cbx_anho' => $cbx_anho,
                    'cbx_mes' => $cbx_mes,
                    'cbx_dia' => $cbx_dia,
                    'rangofecha' => $rangofecha,
                    'fechainicial' => $fechainicial,
                    'fechafinal' => $fechafinal
                ])->html();
} elseif ($_instance->childHasBeenRendered('2N0I50p')) {
    $componentId = $_instance->getRenderedChildComponentId('2N0I50p');
    $componentTag = $_instance->getRenderedChildComponentTagName('2N0I50p');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2N0I50p');
} else {
    $response = \Livewire\Livewire::mount('consulta.onidexes-table',   [
                    'search' => $search,
                    'nombre1' => $nombre1,
                    'nombre2' => $nombre2,
                    'apellido1' => $apellido1,
                    'apellido2' => $apellido2,
                    'cedula' => $cedula,
                    'nacion' => $nacion,
                    'cbx_nombre1' => $cbx_nombre1,
                    'cbx_nombre2' => $cbx_nombre2,
                    'cbx_apellido1' => $cbx_apellido1,
                    'cbx_apellido2' => $cbx_apellido2,
                    'cbx_nombre' => $cbx_nombre,
                    'cbx_apellido' => $cbx_apellido,
                    'cbx_cedula' => $cbx_cedula,
                    'fec_nac' => $fec_nac,
                    'cbx_anho' => $cbx_anho,
                    'cbx_mes' => $cbx_mes,
                    'cbx_dia' => $cbx_dia,
                    'rangofecha' => $rangofecha,
                    'fechainicial' => $fechainicial,
                    'fechafinal' => $fechafinal
                ]);
    $html = $response->html();
    $_instance->logRenderedChild('2N0I50p', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/sefar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sefar\resources\views/consultas/onidex/show.blade.php ENDPATH**/ ?>